rule body
